# CakeBakeryStackApp
 Java project to simulate a cake bakery using a Stack structure.
