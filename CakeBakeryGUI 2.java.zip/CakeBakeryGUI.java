/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ruben_1d
 */


// CakeBakeryGUI.java
// Graphical interface for the Cake Bakery Stack App using Java Swing with pastel theme and Clear Screen button.

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class CakeBakeryGUI extends JFrame {

    private JComboBox<String> cakeTypeDropdown;
    private JTextField cakeWeightField;
    private JTextArea outputArea;
    private OvenStack ovenStack;

    public CakeBakeryGUI() {
        // Set up the frame
        setTitle("Cake Bakery Stack App");
        setSize(700, 500); //to show all buttons
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Define pastel colours
        Color pastelPink = Color.decode("#FADADD");
        Color pastelGreen = Color.decode("#D5F4E6");
        Color pastelYellow = Color.decode("#FFDAB9"); // pastel orange, yellow blens with background
        Color pastelBlue = Color.decode("#D6EAF8");
        Color creamBackground = Color.decode("#FFF5E1");

        // Set background
        getContentPane().setBackground(creamBackground);

        // Initialize OvenStack
        ovenStack = new OvenStack();

        // Top panel: input fields
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBackground(creamBackground);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        inputPanel.add(new JLabel("Select Cake Type:"));
        String[] cakeOptions = {"Pineapple", "Strawberry", "Chocolate", "Vanilla", "Plain"};
        cakeTypeDropdown = new JComboBox<>(cakeOptions);
        inputPanel.add(cakeTypeDropdown);

        inputPanel.add(new JLabel("Enter Weight (g):"));
        cakeWeightField = new JTextField();
        inputPanel.add(cakeWeightField);

        add(inputPanel, BorderLayout.NORTH);

        // Center: output area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setBackground(pastelBlue);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        // Bottom panel: buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(creamBackground);

        JButton addCakeButton = new JButton("Add Cake");
        JButton removeCakeButton = new JButton("Remove Cake");
        JButton peekCakeButton = new JButton("Peek Top Cake");
        JButton clearOvenButton = new JButton("Clear Oven");
        JButton clearOutputButton = new JButton("Clear Screen");

        // Apply pastel colours and force them to show (especially on macOS)
        JButton[] allButtons = {
            addCakeButton, removeCakeButton, peekCakeButton, clearOvenButton, clearOutputButton
        };
        Color[] buttonColors = {
            pastelPink, pastelGreen, pastelYellow, pastelBlue, pastelPink
        };

        for (int i = 0; i < allButtons.length; i++) {
            allButtons[i].setBackground(buttonColors[i]);
            allButtons[i].setOpaque(true);
            allButtons[i].setContentAreaFilled(true);
        }

        // Add buttons to panel
        buttonPanel.add(addCakeButton);
        buttonPanel.add(removeCakeButton);
        buttonPanel.add(peekCakeButton);
        buttonPanel.add(clearOvenButton);
        buttonPanel.add(clearOutputButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // Button listeners
        addCakeButton.addActionListener(e -> {
            String selectedCake = (String) cakeTypeDropdown.getSelectedItem();
            String weightText = cakeWeightField.getText();

            try {
                double weight = Double.parseDouble(weightText);
                if (ovenStack.getCakeCount() < 5) {
                    LocalDateTime timestamp = LocalDateTime.now();
                    Cake newCake = new Cake(selectedCake, weight, timestamp);
                    ovenStack.addCakeToOven(newCake);
                    outputArea.append("Cake added: " + newCake.getCakeName() + "\n");
                } else {
                    outputArea.append("Oven is full. Cannot add more cakes.\n");
                }
            } catch (NumberFormatException ex) {
                outputArea.append("Invalid weight. Please enter a number.\n");
            }

            cakeWeightField.setText("");
        });

        removeCakeButton.addActionListener(e -> {
            Cake removedCake = ovenStack.removeCakeFromOven();
            if (removedCake != null) {
                outputArea.append("Removed: " + removedCake.getCakeName() + "\n");
            } else {
                outputArea.append("Oven is empty. Nothing to remove.\n");
            }
        });

        peekCakeButton.addActionListener(e -> {
            Cake topCake = ovenStack.peekTopCake();
            if (topCake != null) {
                outputArea.append("Top cake: " + topCake.getCakeName() + "\n");
            } else {
                outputArea.append("Oven is empty.\n");
            }
        });

        clearOvenButton.addActionListener(e -> {
            ovenStack.emptyOven();
            outputArea.append("Oven cleared.\n");
        });

        clearOutputButton.addActionListener(e -> outputArea.setText(""));
    }

    // Entry point to run the GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CakeBakeryGUI().setVisible(true));
    }
}