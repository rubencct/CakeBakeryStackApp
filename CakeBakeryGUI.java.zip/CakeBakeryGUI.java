/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ruben_1d
 */
// CakeBakeryGUI.java
// Graphical interface for the Cake Bakery Stack App using Java Swing.

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class CakeBakeryGUI extends JFrame {

    private JComboBox<String> cakeTypeDropdown;
    private JTextField cakeWeightField;
    private JTextArea outputArea;
    private OvenStack ovenStack;

    public CakeBakeryGUI() {
        // Set up the frame
        setTitle("Cake Bakery Stack App");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Initialize OvenStack
        ovenStack = new OvenStack();

        // Top panel: input fields
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2, 10, 10));

        // Cake type dropdown
        inputPanel.add(new JLabel("Select Cake Type:"));
        String[] cakeOptions = {"Pineapple", "Strawberry", "Chocolate", "Vanilla", "Plain"};
        cakeTypeDropdown = new JComboBox<>(cakeOptions);
        inputPanel.add(cakeTypeDropdown);

        // Cake weight field
        inputPanel.add(new JLabel("Enter Weight (g):"));
        cakeWeightField = new JTextField();
        inputPanel.add(cakeWeightField);

        add(inputPanel, BorderLayout.NORTH);

        // Center: output area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        // Bottom panel: buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton addCakeButton = new JButton("Add Cake");
        JButton removeCakeButton = new JButton("Remove Cake");
        JButton peekCakeButton = new JButton("Peek Top Cake");
        JButton clearOvenButton = new JButton("Clear Oven");

        buttonPanel.add(addCakeButton);
        buttonPanel.add(removeCakeButton);
        buttonPanel.add(peekCakeButton);
        buttonPanel.add(clearOvenButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // Button listeners
        addCakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCake = (String) cakeTypeDropdown.getSelectedItem();
                String weightText = cakeWeightField.getText();

                try {
                    double weight = Double.parseDouble(weightText);
                    if (ovenStack.getCakeCount() < 5) {
                        LocalDateTime timestamp = LocalDateTime.now();
                        Cake newCake = new Cake(selectedCake, weight, timestamp);
                        ovenStack.addCakeToOven(newCake);
                        outputArea.append("Cake added: " + newCake.getCakeName() + "\n");
                    } else {
                        outputArea.append("Oven is full. Cannot add more cakes.\n");
                    }
                } catch (NumberFormatException ex) {
                    outputArea.append("Invalid weight. Please enter a number.\n");
                }

                cakeWeightField.setText("");
            }
        });

        removeCakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cake removedCake = ovenStack.removeCakeFromOven();
                if (removedCake != null) {
                    outputArea.append("Removed: " + removedCake.getCakeName() + "\n");
                } else {
                    outputArea.append("Oven is empty. Nothing to remove.\n");
                }
            }
        });

        peekCakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cake topCake = ovenStack.peekTopCake();
                if (topCake != null) {
                    outputArea.append("Top cake: " + topCake.getCakeName() + "\n");
                } else {
                    outputArea.append("Oven is empty.\n");
                }
            }
        });

        clearOvenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ovenStack.emptyOven();
                outputArea.append("Oven cleared.\n");
            }
        });
    }

    // Entry point to run the GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CakeBakeryGUI().setVisible(true));
    }
}
